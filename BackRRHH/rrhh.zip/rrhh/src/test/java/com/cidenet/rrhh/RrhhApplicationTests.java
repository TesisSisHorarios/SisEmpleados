package com.cidenet.rrhh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RrhhApplicationTests {

	@Test
	void contextLoads() {
	}

}
